# Music Library Organizer

Desktopowy organizator biblioteki muzycznej dla Windows 10/11.

## Funkcje

- skanowanie folderu i podfolderów;
- MP3, FLAC, M4A, AAC, OGG, OPUS, WAV;
- odczyt tagów Mutagen + rozpoznawanie nazw plików;
- wyszukiwanie i punktowanie dopasowań MusicBrainz;
- wynik niepewny jest oznaczany jako `Do sprawdzenia`;
- edycja wszystkich głównych pól bezpośrednio w tabeli;
- podgląd STARY/NOWY przed zapisem;
- okładki z Cover Art Archive, z cache po MBID release;
- APIC dla MP3, FLAC Picture, Vorbis/Opus `metadata_block_picture`, MP4 `covr`;
- zmiana nazw z trzema szablonami;
- opcjonalne organizowanie do `Artysta/Album/`;
- bezpieczne unikanie nadpisywania istniejących plików;
- osobny wątek dla operacji sieciowych i skanowania;
- anulowanie, pasek postępu, retry i trwały cache;
- log błędów do `music_organizer.log`.

## Instalacja

W Pythonie 3.11+:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Uruchom:

```powershell
python main.py
```

## EXE

Zainstaluj PyInstaller:

```powershell
pip install pyinstaller
```

Zbuduj:

```powershell
pyinstaller --onefile --windowed main.py
```

Gotowy plik będzie w `dist\main.exe`.

## Ważne

MusicBrainz ogranicza ruch. Program używa własnego User-Agent, cache i odstępu około 1,05 s pomiędzy żądaniami. Nie uruchamiaj wielu kopii programu równocześnie.

Cache znajduje się w:

- `cache\musicbrainz.json`
- `cache\covers\`

Log:

- `music_organizer.log`

AAC i WAV są obsługiwane przez osobne tagi ID3, ponieważ Mutagen nie zapewnia natywnego zapisu tagów AAC, a tagowanie WAV zależy od tego, czy dany odtwarzacz respektuje ID3 w RIFF/WAV.
