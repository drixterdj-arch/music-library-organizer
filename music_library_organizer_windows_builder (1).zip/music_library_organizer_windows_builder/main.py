from __future__ import annotations

import base64
import hashlib
import json
import logging
import mimetypes
import os
import re
import shutil
import threading
import time
import unicodedata
from dataclasses import dataclass, field, asdict
from difflib import SequenceMatcher
from pathlib import Path
from queue import Queue, Empty
from typing import Callable, Optional

import customtkinter as ctk
import requests
from tkinter import filedialog, messagebox, ttk

from mutagen import File
from mutagen.aac import AAC
from mutagen.flac import FLAC, Picture
from mutagen.id3 import ID3, APIC, TALB, TDRC, TPE1, TPE2, TIT2, TPOS, TRCK, ID3NoHeaderError
from mutagen.mp3 import MP3
from mutagen.mp4 import MP4, MP4Cover
from mutagen.oggopus import OggOpus
from mutagen.oggvorbis import OggVorbis


APP_NAME = "Music Library Organizer"
APP_VERSION = "1.0.0"
USER_AGENT = f"{APP_NAME}/{APP_VERSION} (Python; desktop music tagger)"
SUPPORTED_EXTENSIONS = {".mp3", ".flac", ".m4a", ".aac", ".ogg", ".opus", ".wav"}
MB_SEARCH_URL = "https://musicbrainz.org/ws/2"
CAA_URL = "https://coverartarchive.org"
CACHE_DIR = Path("cache")
MB_CACHE_FILE = CACHE_DIR / "musicbrainz.json"
COVER_DIR = CACHE_DIR / "covers"

logging.basicConfig(
    filename="music_organizer.log",
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
LOGGER = logging.getLogger(APP_NAME)


def first_value(value) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return str(value[0]) if value else ""
    return str(value)


def clean_text(value: str) -> str:
    value = first_value(value).replace("\x00", "").strip()
    return re.sub(r"\s+", " ", value)


def normalize(value: str) -> str:
    value = clean_text(value).casefold()
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = re.sub(r"[^\w\s]", " ", value, flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def similarity(a: str, b: str) -> float:
    a, b = normalize(a), normalize(b)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    ratio = SequenceMatcher(None, a, b).ratio()
    at = set(a.split())
    bt = set(b.split())
    token = len(at & bt) / max(1, len(at | bt))
    return 0.65 * ratio + 0.35 * token


def parse_number(value: str) -> str:
    m = re.search(r"\d+", clean_text(value))
    return m.group(0) if m else ""


def parse_pair(value: str) -> tuple[str, str]:
    value = clean_text(value)
    if not value:
        return "", ""
    parts = re.split(r"\s*/\s*", value, maxsplit=1)
    return parse_number(parts[0]), parse_number(parts[1]) if len(parts) > 1 else ""


def safe_filename_part(value: str, fallback: str = "Unknown") -> str:
    value = clean_text(value) or fallback
    value = re.sub(r'[<>:"/\\|?*\x00-\x1F]', "_", value)
    value = value.rstrip(" .")
    if not value:
        value = fallback
    reserved = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
    if value.upper() in reserved:
        value = f"_{value}"
    return value[:180]


def unique_destination(path: Path) -> Path:
    if not path.exists():
        return path
    stem, suffix = path.stem, path.suffix
    for i in range(2, 10000):
        candidate = path.with_name(f"{stem} ({i}){suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"Nie można znaleźć wolnej nazwy dla: {path}")


def filename_metadata(path: Path) -> dict[str, str]:
    stem = path.stem.strip()
    # Remove common leading track/disc numbers.
    stem = re.sub(r"^\s*(?:cd\s*)?\d{1,3}\s*[-_.]\s*", "", stem, flags=re.I)

    if " - " in stem:
        left, right = stem.split(" - ", 1)
        return {"artist": left.strip(), "title": right.strip()}

    if " – " in stem:
        left, right = stem.split(" – ", 1)
        return {"artist": left.strip(), "title": right.strip()}

    if "_" in stem:
        parts = [p.strip() for p in stem.split("_") if p.strip()]
        if len(parts) >= 2:
            return {"artist": parts[0], "title": " ".join(parts[1:])}

    # "01. Artist - Song" after the numeric prefix was already handled.
    parts = re.split(r"\s+-\s+", stem, maxsplit=1)
    if len(parts) == 2:
        return {"artist": parts[0].strip(), "title": parts[1].strip()}

    return {"artist": "", "title": stem}


@dataclass
class TrackRecord:
    path: str
    original: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, str] = field(default_factory=lambda: {
        "title": "", "artist": "", "album": "", "album_artist": "",
        "year": "", "track": "", "disc": ""
    })
    status: str = "Nowy"
    score: float = 0.0
    mbid: str = ""
    release_id: str = ""
    cover_path: str = ""
    selected: bool = True
    error: str = ""


class Cache:
    def __init__(self):
        CACHE_DIR.mkdir(exist_ok=True)
        COVER_DIR.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()
        self.data = self._load()

    def _load(self):
        if not MB_CACHE_FILE.exists():
            return {}
        try:
            return json.loads(MB_CACHE_FILE.read_text(encoding="utf-8"))
        except Exception:
            LOGGER.exception("Nie można wczytać cache MusicBrainz")
            return {}

    def save(self):
        with self.lock:
            tmp = MB_CACHE_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(MB_CACHE_FILE)

    def get(self, key):
        with self.lock:
            return self.data.get(key)

    def put(self, key, value):
        with self.lock:
            self.data[key] = value
        self.save()

    def cover_file(self, release_id: str) -> Path:
        return COVER_DIR / f"{release_id}.jpg"


class RateLimiter:
    def __init__(self, interval: float = 1.05):
        self.interval = interval
        self.lock = threading.Lock()
        self.last_request = 0.0

    def wait(self, cancel: threading.Event):
        with self.lock:
            delay = self.interval - (time.monotonic() - self.last_request)
            if delay > 0:
                end = time.monotonic() + delay
                while time.monotonic() < end:
                    if cancel.is_set():
                        raise InterruptedError
                    time.sleep(min(0.05, end - time.monotonic()))
            self.last_request = time.monotonic()


class MusicBrainzClient:
    def __init__(self, cache: Cache, log: Callable[[str], None], cancel: threading.Event):
        self.cache = cache
        self.log = log
        self.cancel = cancel
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept": "application/json",
        })
        self.limiter = RateLimiter()

    def _request(self, url: str, params: Optional[dict] = None, binary=False):
        last_error = None
        for attempt in range(3):
            if self.cancel.is_set():
                raise InterruptedError
            try:
                self.limiter.wait(self.cancel)
                response = self.session.get(url, params=params, timeout=(10, 30))
                if response.status_code == 503:
                    raise requests.HTTPError("503 Service Unavailable / rate limit", response=response)
                response.raise_for_status()
                return response.content if binary else response.json()
            except InterruptedError:
                raise
            except Exception as exc:
                last_error = exc
                wait = 2 ** attempt
                self.log(f"Zapytanie nieudane ({attempt + 1}/3): {exc}")
                if attempt < 2:
                    for _ in range(wait * 10):
                        if self.cancel.is_set():
                            raise InterruptedError
                        time.sleep(0.1)
        raise RuntimeError(str(last_error))

    @staticmethod
    def _lucene(value: str) -> str:
        value = clean_text(value)
        value = re.sub(r'([+\-&|!(){}\[\]^"~*?:\\/])', r"\\\1", value)
        return f'"{value}"'

    def search_releases(self, artist: str, album: str) -> list[dict]:
        key = "release-search|" + hashlib.sha1(
            f"{normalize(artist)}|{normalize(album)}".encode()
        ).hexdigest()
        cached = self.cache.get(key)
        if cached is not None:
            return cached

        terms = []
        if album:
            terms.append(f"release:{self._lucene(album)}")
        if artist:
            terms.append(f"artist:{self._lucene(artist)}")
        if not terms:
            return []

        data = self._request(
            f"{MB_SEARCH_URL}/release/",
            {"query": " AND ".join(terms), "fmt": "json", "limit": 8},
        )
        results = data.get("releases", [])
        self.cache.put(key, results)
        return results

    def search_recordings(self, artist: str, title: str, album: str) -> list[dict]:
        key = "recording-search|" + hashlib.sha1(
            f"{normalize(artist)}|{normalize(title)}|{normalize(album)}".encode()
        ).hexdigest()
        cached = self.cache.get(key)
        if cached is not None:
            return cached

        terms = [f"recording:{self._lucene(title)}"]
        if artist:
            terms.append(f"artist:{self._lucene(artist)}")
        if album:
            terms.append(f"release:{self._lucene(album)}")

        data = self._request(
            f"{MB_SEARCH_URL}/recording/",
            {"query": " AND ".join(terms), "fmt": "json", "limit": 10},
        )
        results = data.get("recordings", [])
        self.cache.put(key, results)
        return results

    def lookup_release(self, release_id: str) -> dict:
        key = f"release-lookup|{release_id}"
        cached = self.cache.get(key)
        if cached is not None:
            return cached
        data = self._request(
            f"{MB_SEARCH_URL}/release/{release_id}",
            {"fmt": "json", "inc": "recordings+artist-credits"},
        )
        self.cache.put(key, data)
        return data

    @staticmethod
    def release_artist(release: dict) -> str:
        credits = release.get("artist-credit") or []
        names = []
        for item in credits:
            if isinstance(item, dict):
                names.append(item.get("name") or (item.get("artist") or {}).get("name", ""))
                names.append(item.get("joinphrase", ""))
        return clean_text("".join(names))

    @staticmethod
    def track_artist(track: dict, release_artist: str) -> str:
        credits = track.get("artist-credit") or []
        if not credits:
            return release_artist
        parts = []
        for item in credits:
            if isinstance(item, dict):
                parts.append(item.get("name") or (item.get("artist") or {}).get("name", ""))
                parts.append(item.get("joinphrase", ""))
        return clean_text("".join(parts)) or release_artist

    def candidates_for(self, rec: TrackRecord) -> list[dict]:
        m = rec.metadata
        candidates = []

        if m["album"]:
            releases = self.search_releases(m["artist"], m["album"])
            for release in releases[:5]:
                rid = release.get("id")
                if not rid:
                    continue
                try:
                    full = self.lookup_release(rid)
                except Exception as exc:
                    self.log(f"Nie udało się pobrać release {rid}: {exc}")
                    continue
                rel_artist = self.release_artist(full)
                for medium in full.get("media", []):
                    disc_no = str(medium.get("position", ""))
                    for track in medium.get("tracks", []):
                        recording = track.get("recording") or {}
                        candidates.append({
                            "title": clean_text(track.get("title") or recording.get("title", "")),
                            "artist": self.track_artist(track, rel_artist),
                            "album": clean_text(full.get("title", "")),
                            "album_artist": rel_artist,
                            "year": clean_text(full.get("date", ""))[:4],
                            "track": str(track.get("position", "")),
                            "disc": disc_no,
                            "mbid": recording.get("id", ""),
                            "release_id": rid,
                            "mb_score": float(release.get("score", 0)) / 100.0,
                        })
        else:
            results = self.search_recordings(m["artist"], m["title"], "")
            for result in results[:6]:
                rid = ""
                releases = result.get("releases") or []
                if releases:
                    rid = releases[0].get("id", "")
                if not rid:
                    continue
                try:
                    full = self.lookup_release(rid)
                except Exception:
                    continue
                rel_artist = self.release_artist(full)
                for medium in full.get("media", []):
                    for track in medium.get("tracks", []):
                        recording = track.get("recording") or {}
                        if recording.get("id") == result.get("id"):
                            candidates.append({
                                "title": clean_text(track.get("title") or recording.get("title", "")),
                                "artist": self.track_artist(track, rel_artist),
                                "album": clean_text(full.get("title", "")),
                                "album_artist": rel_artist,
                                "year": clean_text(full.get("date", ""))[:4],
                                "track": str(track.get("position", "")),
                                "disc": str(medium.get("position", "")),
                                "mbid": recording.get("id", result.get("id", "")),
                                "release_id": rid,
                                "mb_score": float(result.get("score", 0)) / 100.0,
                            })

            # If the recording result did not expose a release, still use its core fields.
            if not candidates:
                for result in results[:5]:
                    credits = result.get("artist-credit") or []
                    artist = ""
                    if credits:
                        artist = clean_text(credits[0].get("name") or (credits[0].get("artist") or {}).get("name", ""))
                    candidates.append({
                        "title": clean_text(result.get("title", "")),
                        "artist": artist or m["artist"],
                        "album": m["album"],
                        "album_artist": artist or m["artist"],
                        "year": clean_text(result.get("first-release-date", ""))[:4],
                        "track": m["track"],
                        "disc": m["disc"],
                        "mbid": result.get("id", ""),
                        "release_id": rid,
                        "mb_score": float(result.get("score", 0)) / 100.0,
                    })

        # De-duplicate candidates.
        unique = {}
        for c in candidates:
            key = (c["title"], c["artist"], c["album"], c["release_id"], c["track"], c["disc"])
            unique[key] = c
        return list(unique.values())

    @staticmethod
    def score_candidate(source: dict, candidate: dict) -> float:
        title = similarity(source["title"], candidate["title"])
        artist = similarity(source["artist"], candidate["artist"])
        album = similarity(source["album"], candidate["album"])
        text = (title + artist + album) / 3.0
        mb = candidate.get("mb_score", 0.0)
        return 0.45 * title + 0.25 * artist + 0.20 * album + 0.10 * text + 0.10 * mb

    def best_match(self, rec: TrackRecord) -> tuple[Optional[dict], float, float]:
        source = rec.metadata
        candidates = self.candidates_for(rec)
        if not candidates:
            return None, 0.0, 0.0

        ranked = sorted(
            ((self.score_candidate(source, c), c) for c in candidates),
            key=lambda x: x[0],
            reverse=True,
        )
        top_score, top = ranked[0]
        second_score = ranked[1][0] if len(ranked) > 1 else 0.0
        return top, top_score, second_score

    def cover(self, release_id: str) -> Optional[Path]:
        if not release_id:
            return None
        target = self.cache.cover_file(release_id)
        if target.exists() and target.stat().st_size > 0:
            return target

        key = f"cover-url|{release_id}"
        cached_url = self.cache.get(key)
        try:
            if cached_url is None:
                data = self._request(f"{CAA_URL}/release/{release_id}/")
                images = data.get("images", [])
                front = next((x for x in images if x.get("front")), None)
                if front is None and images:
                    front = images[0]
                if not front:
                    self.cache.put(key, "")
                    return None
                cached_url = front.get("image")
                self.cache.put(key, cached_url or "")
            if not cached_url:
                return None

            content = self._request(cached_url, binary=True)
            tmp = target.with_suffix(".tmp")
            tmp.write_bytes(content)
            tmp.replace(target)
            return target
        except Exception as exc:
            self.log(f"Okładka {release_id}: {exc}")
            return None


def read_track(path: Path) -> TrackRecord:
    rec = TrackRecord(path=str(path))
    parsed = filename_metadata(path)
    rec.metadata.update(parsed)

    try:
        ext = path.suffix.lower()
        if ext == ".mp3":
            audio = MP3(path)
            tags = audio.tags
            if tags:
                rec.metadata["title"] = clean_text(tags.get("TIT2", [rec.metadata["title"]])[0])
                rec.metadata["artist"] = clean_text(tags.get("TPE1", [rec.metadata["artist"]])[0])
                rec.metadata["album"] = clean_text(tags.get("TALB", [""])[0])
                rec.metadata["album_artist"] = clean_text(tags.get("TPE2", [""])[0])
                rec.metadata["year"] = clean_text(tags.get("TDRC", [""])[0])[:4]
                rec.metadata["track"], _ = parse_pair(clean_text(tags.get("TRCK", [""])[0]))
                rec.metadata["disc"], _ = parse_pair(clean_text(tags.get("TPOS", [""])[0]))
        elif ext == ".m4a":
            audio = MP4(path)
            tags = audio.tags or {}
            rec.metadata["title"] = clean_text(tags.get("\xa9nam", [rec.metadata["title"]])[0])
            rec.metadata["artist"] = clean_text(tags.get("\xa9ART", [rec.metadata["artist"]])[0])
            rec.metadata["album"] = clean_text(tags.get("\xa9alb", [""])[0])
            rec.metadata["album_artist"] = clean_text(tags.get("aART", [""])[0])
            rec.metadata["year"] = clean_text(tags.get("\xa9day", [""])[0])[:4]
            if tags.get("trkn"):
                rec.metadata["track"] = str(tags["trkn"][0][0])
            if tags.get("disk"):
                rec.metadata["disc"] = str(tags["disk"][0][0])
        elif ext == ".flac":
            audio = FLAC(path)
            tags = audio.tags or {}
            rec.metadata["title"] = clean_text(tags.get("TITLE", [rec.metadata["title"]])[0])
            rec.metadata["artist"] = clean_text(tags.get("ARTIST", [rec.metadata["artist"]])[0])
            rec.metadata["album"] = clean_text(tags.get("ALBUM", [""])[0])
            rec.metadata["album_artist"] = clean_text(tags.get("ALBUMARTIST", [""])[0])
            rec.metadata["year"] = clean_text(tags.get("DATE", [""])[0])[:4]
            rec.metadata["track"], _ = parse_pair(clean_text(tags.get("TRACKNUMBER", [""])[0]))
            rec.metadata["disc"], _ = parse_pair(clean_text(tags.get("DISCNUMBER", [""])[0]))
        elif ext == ".ogg":
            audio = OggVorbis(path)
            tags = audio.tags or {}
            rec.metadata["title"] = clean_text(tags.get("TITLE", [rec.metadata["title"]])[0])
            rec.metadata["artist"] = clean_text(tags.get("ARTIST", [rec.metadata["artist"]])[0])
            rec.metadata["album"] = clean_text(tags.get("ALBUM", [""])[0])
            rec.metadata["album_artist"] = clean_text(tags.get("ALBUMARTIST", [""])[0])
            rec.metadata["year"] = clean_text(tags.get("DATE", [""])[0])[:4]
            rec.metadata["track"], _ = parse_pair(clean_text(tags.get("TRACKNUMBER", [""])[0]))
            rec.metadata["disc"], _ = parse_pair(clean_text(tags.get("DISCNUMBER", [""])[0]))
        elif ext == ".opus":
            audio = OggOpus(path)
            tags = audio.tags or {}
            rec.metadata["title"] = clean_text(tags.get("TITLE", [rec.metadata["title"]])[0])
            rec.metadata["artist"] = clean_text(tags.get("ARTIST", [rec.metadata["artist"]])[0])
            rec.metadata["album"] = clean_text(tags.get("ALBUM", [""])[0])
            rec.metadata["album_artist"] = clean_text(tags.get("ALBUMARTIST", [""])[0])
            rec.metadata["year"] = clean_text(tags.get("DATE", [""])[0])[:4]
            rec.metadata["track"], _ = parse_pair(clean_text(tags.get("TRACKNUMBER", [""])[0]))
            rec.metadata["disc"], _ = parse_pair(clean_text(tags.get("DISCNUMBER", [""])[0]))
        elif ext in {".aac", ".wav"}:
            # Mutagen's AAC parser itself does not tag; ID3 can be stored separately.
            try:
                tags = ID3(path)
            except ID3NoHeaderError:
                tags = None
            if tags:
                rec.metadata["title"] = clean_text(tags.get("TIT2", [rec.metadata["title"]])[0])
                rec.metadata["artist"] = clean_text(tags.get("TPE1", [rec.metadata["artist"]])[0])
                rec.metadata["album"] = clean_text(tags.get("TALB", [""])[0])
                rec.metadata["album_artist"] = clean_text(tags.get("TPE2", [""])[0])
                rec.metadata["year"] = clean_text(tags.get("TDRC", [""])[0])[:4]
                rec.metadata["track"], _ = parse_pair(clean_text(tags.get("TRCK", [""])[0]))
                rec.metadata["disc"], _ = parse_pair(clean_text(tags.get("TPOS", [""])[0]))
    except Exception as exc:
        rec.error = str(exc)
        rec.status = "Błąd odczytu"
        LOGGER.exception("Błąd odczytu %s", path)

    rec.original = dict(rec.metadata)
    if rec.metadata["title"] and rec.metadata["artist"]:
        rec.status = "Odczytano"
    return rec


def write_tags(rec: TrackRecord, cover: Optional[bytes] = None):
    path = Path(rec.path)
    m = rec.metadata
    ext = path.suffix.lower()

    if ext == ".mp3":
        audio = MP3(path)
        if audio.tags is None:
            audio.add_tags()
        tags = audio.tags
        tags.delall("TIT2"); tags.add(TIT2(encoding=3, text=m["title"]))
        tags.delall("TPE1"); tags.add(TPE1(encoding=3, text=m["artist"]))
        tags.delall("TALB"); tags.add(TALB(encoding=3, text=m["album"]))
        tags.delall("TPE2"); tags.add(TPE2(encoding=3, text=m["album_artist"]))
        tags.delall("TDRC"); tags.add(TDRC(encoding=3, text=m["year"]))
        tags.delall("TRCK"); tags.add(TRCK(encoding=3, text=m["track"]))
        tags.delall("TPOS"); tags.add(TPOS(encoding=3, text=m["disc"]))
        if cover:
            tags.delall("APIC")
            mime = "image/jpeg" if cover[:3] == b"\xff\xd8\xff" else "image/png"
            tags.add(APIC(encoding=3, mime=mime, type=3, desc="Cover", data=cover))
        audio.save()

    elif ext == ".flac":
        audio = FLAC(path)
        audio["TITLE"] = [m["title"]]
        audio["ARTIST"] = [m["artist"]]
        audio["ALBUM"] = [m["album"]]
        audio["ALBUMARTIST"] = [m["album_artist"]]
        audio["DATE"] = [m["year"]]
        audio["TRACKNUMBER"] = [m["track"]]
        audio["DISCNUMBER"] = [m["disc"]]
        if cover:
            audio.clear_pictures()
            pic = Picture(cover)
            pic.type = 3
            pic.mime = "image/jpeg" if cover[:3] == b"\xff\xd8\xff" else "image/png"
            audio.add_picture(pic)
        audio.save()

    elif ext == ".m4a":
        audio = MP4(path)
        if audio.tags is None:
            audio.add_tags()
        audio["\xa9nam"] = [m["title"]]
        audio["\xa9ART"] = [m["artist"]]
        audio["\xa9alb"] = [m["album"]]
        audio["aART"] = [m["album_artist"]]
        audio["\xa9day"] = [m["year"]]
        audio["trkn"] = [(int(m["track"] or 0), 0)]
        audio["disk"] = [(int(m["disc"] or 0), 0)]
        if cover:
            fmt = MP4Cover.FORMAT_JPEG if cover[:3] == b"\xff\xd8\xff" else MP4Cover.FORMAT_PNG
            audio["covr"] = [MP4Cover(cover, imageformat=fmt)]
        audio.save()

    elif ext in {".ogg", ".opus"}:
        audio = OggVorbis(path) if ext == ".ogg" else OggOpus(path)
        audio["TITLE"] = [m["title"]]
        audio["ARTIST"] = [m["artist"]]
        audio["ALBUM"] = [m["album"]]
        audio["ALBUMARTIST"] = [m["album_artist"]]
        audio["DATE"] = [m["year"]]
        audio["TRACKNUMBER"] = [m["track"]]
        audio["DISCNUMBER"] = [m["disc"]]
        if cover:
            pic = Picture(cover)
            pic.type = 3
            pic.mime = "image/jpeg" if cover[:3] == b"\xff\xd8\xff" else "image/png"
            audio["metadata_block_picture"] = [
                base64.b64encode(pic.write()).decode("ascii")
            ]
        audio.save()

    elif ext in {".aac", ".wav"}:
        try:
            tags = ID3(path)
        except ID3NoHeaderError:
            tags = ID3()
        tags.delall("TIT2"); tags.add(TIT2(encoding=3, text=m["title"]))
        tags.delall("TPE1"); tags.add(TPE1(encoding=3, text=m["artist"]))
        tags.delall("TALB"); tags.add(TALB(encoding=3, text=m["album"]))
        tags.delall("TPE2"); tags.add(TPE2(encoding=3, text=m["album_artist"]))
        tags.delall("TDRC"); tags.add(TDRC(encoding=3, text=m["year"]))
        tags.delall("TRCK"); tags.add(TRCK(encoding=3, text=m["track"]))
        tags.delall("TPOS"); tags.add(TPOS(encoding=3, text=m["disc"]))
        if cover:
            tags.delall("APIC")
            mime = "image/jpeg" if cover[:3] == b"\xff\xd8\xff" else "image/png"
            tags.add(APIC(encoding=3, mime=mime, type=3, desc="Cover", data=cover))
        tags.save(path)


def template_name(rec: TrackRecord, template: str) -> str:
    values = {
        "track": (rec.metadata["track"] or "00").zfill(2),
        "artist": safe_filename_part(rec.metadata["artist"], "Unknown Artist"),
        "title": safe_filename_part(rec.metadata["title"], "Unknown Title"),
    }
    return template.format(**values) + Path(rec.path).suffix.lower()


class OrganizerApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("1500x900")
        self.minsize(1200, 700)
        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")

        self.records: list[TrackRecord] = []
        self.row_widgets = []
        self.worker: Optional[threading.Thread] = None
        self.cancel_event = threading.Event()
        self.events: Queue = Queue()
        self.cache = Cache()
        self.preview_confirmed = False
        self.root_folder = Path.cwd()

        self._build_ui()
        self.after(100, self._poll_events)

    def _build_ui(self):
        top = ctk.CTkFrame(self)
        top.pack(fill="x", padx=10, pady=10)

        buttons = [
            ("Wybierz folder", self.choose_folder),
            ("Dodaj pliki", self.add_files),
            ("Skanuj", self.scan),
            ("Znajdź metadane", self.find_metadata),
            ("Podgląd", self.preview),
            ("Zapisz zmiany", self.save_changes),
            ("Pobierz okładki", self.download_covers),
            ("Zmień nazwy plików", self.rename_files),
        ]
        for text, command in buttons:
            ctk.CTkButton(top, text=text, command=command, width=145).pack(side="left", padx=4, pady=8)

        self.folder_label = ctk.CTkLabel(top, text="Folder: —", anchor="w")
        self.folder_label.pack(side="left", padx=15, fill="x", expand=True)

        options = ctk.CTkFrame(self)
        options.pack(fill="x", padx=10, pady=(0, 8))

        ctk.CTkLabel(options, text="Szablon nazwy:").pack(side="left", padx=(10, 4))
        self.template = ctk.CTkComboBox(
            options,
            values=["{track} - {artist} - {title}", "{track} - {title}", "{artist} - {title}"],
            width=260,
        )
        self.template.set("{track} - {artist} - {title}")
        self.template.pack(side="left", padx=4)

        self.move_var = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(options, text="Organizuj do Artysta/Album/", variable=self.move_var).pack(side="left", padx=12)

        self.recursive_var = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(options, text="Skanuj podfoldery", variable=self.recursive_var).pack(side="left", padx=12)

        self.cancel_button = ctk.CTkButton(options, text="Anuluj", command=self.cancel_operation, state="disabled", width=100)
        self.cancel_button.pack(side="right", padx=10)

        self.progress = ctk.CTkProgressBar(self)
        self.progress.pack(fill="x", padx=10, pady=(0, 4))
        self.progress.set(0)

        self.progress_label = ctk.CTkLabel(self, text="Gotowe")
        self.progress_label.pack(anchor="w", padx=12)

        table = ctk.CTkFrame(self)
        table.pack(fill="both", expand=True, padx=10, pady=8)

        headers = [
            ("✓", 45), ("Status", 105), ("Plik", 270), ("Tytuł", 170),
            ("Wykonawca", 160), ("Album", 170), ("Wyk. albumu", 160),
            ("Rok", 70), ("Track", 60), ("Disc", 60)
        ]
        for col, (text, width) in enumerate(headers):
            ctk.CTkLabel(table, text=text, width=width, anchor="w").grid(
                row=0, column=col, padx=2, pady=4, sticky="ew"
            )
            table.grid_columnconfigure(col, minsize=width, weight=0)

        self.rows_frame = ctk.CTkScrollableFrame(table, label_text="")
        self.rows_frame.grid(row=1, column=0, columnspan=len(headers), sticky="nsew", padx=2, pady=2)
        table.grid_rowconfigure(1, weight=1)
        table.grid_columnconfigure(2, weight=1)

        log_frame = ctk.CTkFrame(self)
        log_frame.pack(fill="x", padx=10, pady=(0, 10))
        ctk.CTkLabel(log_frame, text="Log:").pack(anchor="w", padx=8, pady=(5, 0))
        self.log_box = ctk.CTkTextbox(log_frame, height=100)
        self.log_box.pack(fill="x", padx=8, pady=6)
        self.log_box.configure(state="disabled")

    def log(self, message: str):
        LOGGER.info(message)
        self.events.put(("log", message))

    def choose_folder(self):
        folder = filedialog.askdirectory(title="Wybierz folder z muzyką")
        if folder:
            self.root_folder = Path(folder)
            self.folder_label.configure(text=f"Folder: {folder}")
            self.scan()

    def add_files(self):
        paths = filedialog.askopenfilenames(
            title="Dodaj pliki muzyczne",
            filetypes=[("Pliki muzyczne", "*.mp3 *.flac *.m4a *.aac *.ogg *.opus *.wav")],
        )
        if not paths:
            return
        existing = {os.path.normcase(r.path) for r in self.records}
        for p in paths:
            if os.path.normcase(p) not in existing:
                self.records.append(read_track(Path(p)))
        self.refresh_table()
        self.log(f"Dodano {len(paths)} plików.")

    def scan(self):
        if self.worker and self.worker.is_alive():
            return
        folder = self.root_folder
        if not folder.exists():
            messagebox.showwarning("Folder", "Najpierw wybierz istniejący folder.")
            return

        def job():
            try:
                paths = []
                iterator = folder.rglob("*") if self.recursive_var.get() else folder.iterdir()
                for p in iterator:
                    if self.cancel_event.is_set():
                        return
                    if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS:
                        paths.append(p)
                records = []
                total = len(paths)
                for i, p in enumerate(paths, 1):
                    if self.cancel_event.is_set():
                        return
                    records.append(read_track(p))
                    self.events.put(("progress", i, total, f"Skanowanie: {p.name}"))
                self.events.put(("scan_done", records))
            except Exception as exc:
                self.events.put(("error", f"Skanowanie: {exc}"))

        self.start_worker(job)

    def find_metadata(self):
        if not self.records:
            messagebox.showinfo("Metadane", "Najpierw zeskanuj folder lub dodaj pliki.")
            return

        def job():
            client = MusicBrainzClient(self.cache, self.log, self.cancel_event)
            total = len(self.records)
            for i, rec in enumerate(self.records, 1):
                if self.cancel_event.is_set():
                    return
                try:
                    # Prefer current editor values, but keep filename-derived fallback.
                    best, score, second = client.best_match(rec)
                    if best:
                        rec.metadata.update({
                            "title": best["title"],
                            "artist": best["artist"],
                            "album": best["album"],
                            "album_artist": best["album_artist"],
                            "year": best["year"],
                            "track": best["track"],
                            "disc": best["disc"],
                        })
                        rec.score = score
                        rec.mbid = best["mbid"]
                        rec.release_id = best["release_id"]
                        rec.status = "OK" if score >= 0.78 and (score - second >= 0.05 or second == 0) else "Do sprawdzenia"
                        rec.error = ""
                    else:
                        rec.status = "Nie znaleziono"
                        rec.score = 0
                except InterruptedError:
                    return
                except Exception as exc:
                    rec.status = "Błąd"
                    rec.error = str(exc)
                    self.log(f"{Path(rec.path).name}: {exc}")
                self.events.put(("record_updated", i, total, rec.path, rec.status, rec.score))
            self.events.put(("metadata_done",))

        self.start_worker(job)

    def download_covers(self):
        selected = [r for r in self.records if r.selected and r.release_id]
        if not selected:
            messagebox.showinfo("Okładki", "Brak zaznaczonych utworów z rozpoznanym albumem.")
            return

        def job():
            client = MusicBrainzClient(self.cache, self.log, self.cancel_event)
            done = 0
            total = len(selected)
            by_release = {}
            for rec in selected:
                by_release.setdefault(rec.release_id, []).append(rec)
            for rid, records in by_release.items():
                if self.cancel_event.is_set():
                    return
                try:
                    cover = client.cover(rid)
                    for rec in records:
                        rec.cover_path = str(cover) if cover else ""
                        rec.status = rec.status if cover else "Brak okładki"
                        done += 1
                        self.events.put(("progress", done, total, f"Okładka: {Path(rec.path).name}"))
                except Exception as exc:
                    self.log(f"Okładka {rid}: {exc}")
                    done += len(records)
            self.events.put(("covers_done",))

        self.start_worker(job)

    def start_worker(self, job):
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("Operacja", "Inna operacja jest już wykonywana.")
            return
        self.cancel_event.clear()
        self.cancel_button.configure(state="normal")
        self.progress.set(0)
        self.worker = threading.Thread(target=job, daemon=True)
        self.worker.start()

    def cancel_operation(self):
        self.cancel_event.set()
        self.progress_label.configure(text="Anulowanie…")

    def refresh_table(self):
        for widget in self.row_widgets:
            widget.destroy()
        self.row_widgets.clear()

        for i, rec in enumerate(self.records):
            self._make_row(i, rec)

    def _make_row(self, index: int, rec: TrackRecord):
        frame = ctk.CTkFrame(self.rows_frame)
        frame.grid(row=index, column=0, sticky="ew", padx=2, pady=1)
        frame.grid_columnconfigure(2, weight=1)
        self.row_widgets.append(frame)

        selected = ctk.BooleanVar(value=rec.selected)
        cb = ctk.CTkCheckBox(frame, text="", width=35, variable=selected,
                             command=lambda r=rec, v=selected: setattr(r, "selected", bool(v.get())))
        cb.grid(row=0, column=0, padx=3)

        status = ctk.CTkLabel(frame, text=rec.status, width=105, anchor="w")
        status.grid(row=0, column=1, padx=2, sticky="w")

        path_label = ctk.CTkLabel(frame, text=Path(rec.path).name, width=270, anchor="w")
        path_label.grid(row=0, column=2, padx=2, sticky="w")

        keys = ["title", "artist", "album", "album_artist", "year", "track", "disc"]
        widths = [170, 160, 170, 160, 70, 60, 60]
        for col, (key, width) in enumerate(zip(keys, widths), start=3):
            var = ctk.StringVar(value=rec.metadata[key])
            entry = ctk.CTkEntry(frame, textvariable=var, width=width)
            entry.grid(row=0, column=col, padx=2, sticky="ew")
            entry.bind("<FocusOut>", lambda _e, r=rec, k=key, v=var: r.metadata.__setitem__(k, v.get().strip()))
            entry.bind("<Return>", lambda _e, r=rec, k=key, v=var: r.metadata.__setitem__(k, v.get().strip()))

    def preview(self):
        if not self.records:
            return
        lines = []
        for rec in self.records:
            if not rec.selected:
                continue
            old = " - ".join(x for x in [rec.original.get("artist"), rec.original.get("album"), rec.original.get("title")] if x)
            new = " - ".join(x for x in [rec.metadata.get("artist"), rec.metadata.get("album"), rec.metadata.get("title")] if x)
            if old != new or rec.status in {"OK", "Do sprawdzenia"}:
                confidence = f"{rec.score * 100:.0f}%"
                lines.append(f"{Path(rec.path).name}\n  STARY: {old or '—'}\n  NOWY:  {new or '—'}\n  Status: {rec.status}, dopasowanie: {confidence}\n")
        if not lines:
            lines = ["Brak zaznaczonych zmian."]
        self.preview_confirmed = True
        self._text_dialog("Podgląd zmian", "\n".join(lines[:500]), "Zamknij")

    def _text_dialog(self, title, text, button):
        win = ctk.CTkToplevel(self)
        win.title(title)
        win.geometry("900x650")
        win.transient(self)
        box = ctk.CTkTextbox(win)
        box.pack(fill="both", expand=True, padx=10, pady=10)
        box.insert("1.0", text)
        box.configure(state="disabled")
        ctk.CTkButton(win, text=button, command=win.destroy).pack(pady=(0, 10))

    def save_changes(self):
        if not self.records:
            return
        if not self.preview_confirmed:
            self.preview()
            messagebox.showinfo("Podgląd wymagany", "Sprawdź podgląd. Po zamknięciu okna kliknij „Zapisz zmiany” ponownie.")
            return

        selected = [r for r in self.records if r.selected]
        if not selected:
            return

        def job():
            total = len(selected)
            for i, rec in enumerate(selected, 1):
                if self.cancel_event.is_set():
                    return
                try:
                    cover = Path(rec.cover_path).read_bytes() if rec.cover_path and Path(rec.cover_path).exists() else None
                    write_tags(rec, cover)
                    rec.original = dict(rec.metadata)
                    rec.status = "Zapisano"
                except Exception as exc:
                    rec.status = "Błąd zapisu"
                    rec.error = str(exc)
                    self.log(f"Zapis {rec.path}: {exc}")
                self.events.put(("progress", i, total, f"Zapisywanie: {Path(rec.path).name}"))
            self.events.put(("save_done",))

        self.start_worker(job)

    def rename_files(self):
        selected = [r for r in self.records if r.selected]
        if not selected:
            return

        tmpl = self.template.get().strip()

        def job():
            total = len(selected)
            for i, rec in enumerate(selected, 1):
                if self.cancel_event.is_set():
                    return
                try:
                    old_path = Path(rec.path)
                    new_name = template_name(rec, tmpl)
                    target_dir = old_path.parent
                    if self.move_var.get():
                        artist_dir = safe_filename_part(rec.metadata["artist"], "Unknown Artist")
                        album_dir = safe_filename_part(rec.metadata["album"], "Unknown Album")
                        target_dir = self.root_folder / artist_dir / album_dir
                        target_dir.mkdir(parents=True, exist_ok=True)
                    target = unique_destination(target_dir / new_name)
                    if os.path.normcase(str(target)) != os.path.normcase(str(old_path)):
                        shutil.move(str(old_path), str(target))
                        rec.path = str(target)
                    rec.status = "Zmieniono nazwę"
                except Exception as exc:
                    rec.status = "Błąd nazwy"
                    rec.error = str(exc)
                    self.log(f"Nazwa {rec.path}: {exc}")
                self.events.put(("progress", i, total, f"Nazwa: {Path(rec.path).name}"))
            self.events.put(("rename_done",))

        self.start_worker(job)

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "log":
                    self.log_box.configure(state="normal")
                    self.log_box.insert("end", event[1] + "\n")
                    self.log_box.see("end")
                    self.log_box.configure(state="disabled")
                elif kind == "progress":
                    _, done, total, text = event
                    self.progress.set(done / max(total, 1))
                    self.progress_label.configure(text=f"{done}/{total} — {text}")
                elif kind == "scan_done":
                    self.records = event[1]
                    self.refresh_table()
                    self.progress_label.configure(text=f"Znaleziono {len(self.records)} plików.")
                    self.preview_confirmed = False
                    self._worker_finished()
                elif kind == "record_updated":
                    self.refresh_table()
                elif kind in {"metadata_done", "covers_done", "save_done", "rename_done"}:
                    self.refresh_table()
                    self.preview_confirmed = False if kind != "save_done" else True
                    self._worker_finished()
                elif kind == "error":
                    messagebox.showerror("Błąd", event[1])
                    self._worker_finished()
        except Empty:
            pass
        self.after(100, self._poll_events)

    def _worker_finished(self):
        self.cancel_button.configure(state="disabled")
        self.progress_label.configure(text="Gotowe")

    def close(self):
        self.cancel_event.set()
        self.destroy()

    def destroy(self):
        self.cancel_event.set()
        super().destroy()


if __name__ == "__main__":
    app = OrganizerApp()
    app.protocol("WM_DELETE_WINDOW", app.close)
    app.mainloop()
